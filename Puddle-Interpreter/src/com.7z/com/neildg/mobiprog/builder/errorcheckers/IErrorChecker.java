/**
 * 
 */
package com.neildg.mobiprog.builder.errorcheckers;

/**A custom error checker
 * @author Patrick
 *
 */
public interface IErrorChecker {
	public abstract void verify();
}
