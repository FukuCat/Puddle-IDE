/**
 * 
 */
package com.neildg.mobiprog.execution.commands;

/**
 * Represents a runnable command
 * @author Patrick
 *
 */
public interface ICommand {

	public abstract void execute();
}
