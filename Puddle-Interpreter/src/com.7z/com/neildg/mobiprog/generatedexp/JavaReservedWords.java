package com.neildg.mobiprog.generatedexp;

public class JavaReservedWords {

	public final static String[] KEYWORDS = {
		"<INVALID>", "abstract", "assert", "boolean", "break", "byte", 
		"case", "catch", "char", "class", "const", "continue", "default", 
		"do", "double", "else", "enum", "extends", "final", "finally", 
		"float", "for", "if", "goto", "implements", "import", "instanceof", 
		"int", "interface", "long", "native", "new", "package", "private", 
		"protected", "public", "return", "short", "static", "strictfp", 
		"super", "switch", "synchronized", "this", "throw", "throws", 
		"transient", "try", "void", "volatile", "while", "print", "main", "scan"
	};
}
